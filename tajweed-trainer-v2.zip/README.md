# Tajweed Trainer v2
انظر الشرح المرفق في الدردشة.
