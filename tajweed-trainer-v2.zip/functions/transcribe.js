
exports.handler = async (event) => {
  try {
    if (event.httpMethod !== 'POST') {
      return { statusCode: 405, body: 'Method Not Allowed' };
    }
    const { audio_b64, mime = 'audio/webm', language = 'ar' } =
      JSON.parse(event.body || '{}');
    if (!audio_b64) {
      return { statusCode: 400, body: 'Missing audio_b64' };
    }
    const bytes = Buffer.from(audio_b64, 'base64');
    const blob = new Blob([bytes], { type: mime });
    const fd = new FormData();
    fd.append('file', blob, 'audio.webm');
    fd.append('model', 'whisper-1');
    fd.append('response_format', 'verbose_json');
    if (language) fd.append('language', language);
    const resp = await fetch('https://api.openai.com/v1/audio/transcriptions', {
      method: 'POST',
      headers: { Authorization: `Bearer ${process.env.OPENAI_API_KEY}` },
      body: fd
    });
    const text = await resp.text();
    return { statusCode: resp.status, body: text };
  } catch (err) {
    return { statusCode: 500, body: String(err) };
  }
};
